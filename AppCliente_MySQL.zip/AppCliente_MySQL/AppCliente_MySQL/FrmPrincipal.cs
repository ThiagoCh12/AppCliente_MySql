﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCliente_MySQL
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            Cliente cliente = new Cliente();
            List<Cliente> clientes = cliente.listacliente();
            dgvCliente.DataSource = clientes;
            

        }

        private void button3_Click(object sender, EventArgs e) // INSERIR
        {
            try
            {
                Cliente cliente = new Cliente();
                if (cliente.RegistroRepetido(txtNome.Text, txtCelular.Text) == true ) 
                {
                    MessageBox.Show("Cliente existente na base de dados", "Cliente repetido", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNome.Text = "";
                    txtCelular.Text = "";
                    return;
                }
                else
                {
                    cliente.Inserir(txtNome.Text, txtCelular.Text);
                    MessageBox.Show("Cliente inserido com sucesso!", "Cliente registrado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Cliente> clientes = cliente.listacliente();
                    dgvCliente.DataSource= clientes;
                    txtNome.Text = "";
                    txtCelular.Text = "";
                    this.txtNome.Focus();  //cursor volta pro txtBox nome
                }
            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)//editar
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Atualizar(id, txtNome.Text, txtCelular.Text);
                MessageBox.Show("Cliente atualizado com sucesso!", "Atualização", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> clientes= cliente.listacliente();
                dgvCliente.DataSource = clientes;
                txtNome.Text = "";
                txtCelular.Text = "";
                txtId.Text = "";
                this.txtNome.Focus();

            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button4_Click(object sender, EventArgs e) //fechar
        {
            Environment.Exit(0);    
        }

        private void button1_Click(object sender, EventArgs e) //localizar
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Localizar(id);
                txtNome.Text = cliente.nome;
                txtCelular.Text = cliente.celular;
            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e) //excluir
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Cliente cliente = new Cliente();
                cliente.Excluir(id);
                MessageBox.Show("Cliente excluido com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Cliente> clientes = cliente.listacliente();
                dgvCliente.DataSource = clientes;
                txtNome.Text = "";
                txtCelular.Text = "";
                txtId.Text = "";
                this.txtNome.Focus();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dgvCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCliente.Rows[e.RowIndex];
                this.dgvCliente.Rows[e.RowIndex].Selected = true;
                txtId.Text = row.Cells[0].Value.ToString();
                txtNome.Text = row.Cells[1].Value.ToString();
                txtCelular.Text = row.Cells[2].Value.ToString();
            }
        }
    }
}
